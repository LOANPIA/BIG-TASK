//v0 la dinh nguon --tuong tu nhu ly thuyet la S, 
//source code nay da xac dinh S la tap hop dinh 
//nen dung v0 de thay the
//(X) la dinh xuat phat can xac dinh duong di 
//v la dich (Y)

#include <stdio.h>
#define size 100
#define duongvocuc 3.40282e+38 //so float 32 bit lon nhat

//Ham doc file
void readFile(char file_name[], float A[][size], int *n){
	int i,j;
	FILE *f;
	f=fopen(file_name, "r");
	
	if(f==NULL){
		printf("File Error!Loading...");
		return;
	}
	
	fscanf(f,"%d",n); //Doc so dinh cua do thi n
	
	for(i=0; i<*n; i++)
		for(j=0; j<*n; j++)
			fscanf(f, "%f", &A[i][j]);
			
	fclose(f);
}

//Ham In Ma Tran
void PrintMatrix(float A[][size], int n){
	int i,j;
	system("cls"); //Xoa Man Hinh
	printf("Ma tran trong so ban dau\n");
	for(i=0; i<n; i++){
		for(j=0; j<n; j++)
			if(A[i][j]<duongvocuc)
				printf("%8.2f", A[i][j]);
			else
				printf("%8c",236); //236 la ma ASCII cua ky hieu vo cuc
		printf("\n");
	}
}

//Ham khoi tao cac du lieu ban dau
void init(float dong_v0[], int v0, int S[], float D[], int P[], int n){
// dong_X la dong co trong so trong ma tran A
// v0 la dinh nguon
// S la tap hop cac dinh
// D la do dai nho nhat cac duong di
// P la mang cac dinh truy vet
// n la so dinh trong ma tran do thi
	int v;
	for(v=0; v<n; v++){
		S[v] = 0;			//tat ca cac dinh v khac v0 deu thuoc V-S (ngoai tap hop S)
		D[v] = dong_v0[v];   //Do dai duong di tu dinh v0 toi v la A[v0][v] tuc la dong_v0[v]
		P[v] = v0;			//Dung truoc v la v0
	}
	S[v0] = 1; //Dua X vao tap S
}

//Ham chon dinh
int SelectVertex(int S[], float D[], int n){
	int u, umin;
	float emin = duongvocuc;
	
	for(u=0; u<n; u++){
		//Neu dinh u chua xac dinh ngoai tap S va nho hon +oo
		if(!S[u] && D[u]<emin){
			emin = D[u];
			umin = u;
		}
	}
	u = umin; 		//Dinh u chon duoc
	D[u] = emin; 	//Do dai duong di tu v0 toi dinh chon duoc u la do dai nho nhat emin
	return u;
}

//Ham cap nhat
void UPDATE(float A[][size], int S[], float D[], int P[], int u, int n){
	int v;
	
	S[u] = 1; //Them u vao S
	
	for(v=0; v<n; v++)
		if(!S[v] && D[v] > D[u] + A[u][v]){
			D[v] = D[u] + A[u][v];
			P[v] = u;
		}
}

//Ham tim duong di ngan nhat theo thuat toan Dijkstra
void Dijkstra(float A[][size], int v0, int n, int P[]){
	int u,i;
	int S[n];		//S[u] == 1 dinh u thuoc S, S[u] == 0 dinh u thuoc V-S
    float D[n];		//D[v] la do dai duong di tu dinh v0 den dinh v
    
    init(A[v0], v0, S, D, P, n); //A[v0] do dai cac canh xuat phat tu dinh v0
    
    for(i=1; i<n; i++){	//la n-1 lan
    	u = SelectVertex(S,D,n);
    	UPDATE(A,S,D,P,u,n);
	}
}

//Ham in ket qua
void PrintResult(float A[][size], int P[], int v0, int Y, float tong){
	// Neu khong co mot duong di tu dinh v0 toi dich Y
	// Do phan khoi tao ta dat P[v] = v0 voi moi v (truy vet duong di)
	// Se khong co update nen P[Y] = v0, do dai canh (v0, Y) = duongvocuc
	// => Chi in ra nhung canh co do dai < duongvocuc
	
	FILE *fp;
	fp = fopen("Output.txt", "w");
	//if (fp == NULL) {
      //  printf("Error!");
    //}
	if(A[P[Y]][Y] < duongvocuc && Y!= v0){
		int dinhTruocY = P[Y];
		PrintResult(A, P, v0, dinhTruocY, tong + A[dinhTruocY][Y]);
//		while(v0 >= 0 && v0 == Y){
//			fprintf(fp,"(%d,%d) = %5.2f\n", dinhTruocY, Y, A[dinhTruocY][Y]);
//		}
		fprintf(fp,"(%d,%d) = %5.2f\n", v0, dinhTruocY, A[v0][dinhTruocY]);
		fprintf(fp,"(%d,%d) = %5.2f\n", dinhTruocY, Y, A[dinhTruocY][Y]);
		printf("(%d,%d) = %5.2f\n", dinhTruocY, Y, A[dinhTruocY][Y]);
	}else{
		if(tong == 0){
			fprintf(fp, "Khong co duong di tu dinh X(%d) den dinh Y(%d)\n", v0, Y);
			printf("Khong co duong di tu dinh X(%d) den dinh Y(%d)\n", v0, Y);
		}else{
			fprintf(fp,"-------------------------------------------------\n");
			fprintf(fp, "Co duong di tu dinh X den dinh Y\n");
			printf("Co duong di tu dinh X den dinh Y da chon\n", v0, Y);
			fprintf(fp, "&---Tong do dai cac canh= %8.2f\n",tong);
			printf("Tong do dai cac canh = %8.2f\n", tong);
		}
	}
	fclose(fp);
}

//Ham ghi ket qua vao file Output.txt
//void outResult() {
	//fopen_s(&fp, "Output.txt", "w");       
//}

//Ham chinh
int main(){
	float A[size][size]; //Ma tran trong so cua do thi
	int n, v0 = 0, Y = 0;
	
	readFile("Input.txt", A, &n);
	
	PrintMatrix(A, n);
	int P[n]; //P[u] luu tru dinh dung truoc u trong duong di tu v0 den u
	
	while(v0 != -1){
		printf("\nNhap dinh NGUON v0 (tu 0 den %d; Nhap -1 de ket thuc): ", n-1);
		scanf("%d", &v0);
		if(v0 >= 0 && v0 <= n-1){
			Dijkstra(A, v0, n, P);
			Y = 0;
			while(Y!=-1){
				printf("\nNhap dinh dich Y (tu 0 den %d; nhap -1 de chon v0 khac): ", n-1);
				scanf("%d", &Y);
				if(Y>=0 && Y<=n-1){
					printf("\nDuong di ngan nhat tu X(%d) den Y(%d) la: \n", v0, Y);
					PrintResult(A, P, v0, Y, 0.00);
				}
			}
			PrintMatrix(A, n);
		}
	}
	return 0;
}
