#include <stdio.h>
#include <stdlib.h>

struct Node{
	int data;
	//char s[100]; //xamxi
	struct Node* pNext; 
}; 
typedef struct Node NODE;

NODE *pTop = NULL; 

/*
-- IsEmpty
-- Push
-- Pop
-- Top
*/

// --IsEmpty 
int IsEmpty(){
	if(pTop == NULL)
		return 1; 
	else
		return 0; 
}

//Push 
void Push(int x){
	NODE *p;
	p= (NODE*)malloc(sizeof(NODE));
	if(p == NULL){
		printf("\nKhong du bo nho de cap phat");
		return; 
	}else{
	p->data=x;
	p->pNext = pTop; //cho con tro cua NODE p tro den NODE dau ds <=> tao lien ket  
	pTop = p; //cap nhat lai NODE dau  
	}
} 

//Pop --tuong duong removeHead SLL 
int Pop(){
	int x; 
	if(IsEmpty()){
		printf("Danh sach lien ket rong!\n");
		exit(1); 
	}else{
		NODE *p = pTop;
		x = p->data; 
		pTop = pTop->pNext; 
		free(p);
		return x; 
	}
} 

//Top
int Top(){
	if(IsEmpty()){
		printf("\nStack Underflow\n");
        exit(1);
	}else{
		return pTop->data; //lay gia tri cua ptu dau STACK
	} 
} 

void DisplayStack(){
	NODE *p;
	p = pTop; 
	if(IsEmpty()){
		printf("\nStack Underflow\n");
        return;
	} 
	while (p!=NULL) 
		{
			printf("%d ",p->data);
			p = p->pNext;
		}
}

NODE* InitNode(int x){
	NODE *p;
	p= (NODE*)malloc(sizeof(NODE));
	if(p == NULL){
		printf("\nKhong du bo nho de cap phat");
		return NULL; 
	}else{
	p->data=x;
	p->pNext=NULL;
	}
	return p;
} 
void GetStackFromFile(NODE **pTop,NODE *p){ //them den cuoi
	NODE *TOP = *pTop;	
	if (TOP == NULL)
		TOP = p; //NODE p ch�nh l� NODE dau STACK 
	else
	{
		NODE *q=TOP;
		while (q->pNext!=NULL)
			q=q->pNext;
		q->pNext = p;
	}
	*pTop = TOP;
}
int main(){ 
	int x; 
	NODE *p;  
	pTop = NULL; 
    FILE *f = fopen("STACK.txt", "r");
    if (f==NULL)
		return 0;
    while (fscanf(f,"%d",&x) != EOF)
    {
    	p = InitNode(x);
		GetStackFromFile(&pTop,p); 
		printf("%d\n",x);
	}		
 	int choice;
        while(1)
        {
                printf("\n1.Push\n");
                printf("2.Pop\n");
                printf("3.Display item at the top\n");
                printf("4.Display all items of the stack\n");
                printf("5.Quit\n");
                printf("\nEnter your choice : ") ;
                scanf("%d", &choice);

                switch(choice)
                {
                case 1:
                        printf("\nEnter the item to be pushed : ");
                        scanf("%d",&x);
                        Push(x);
                        break;
                case 2:
                        x=Pop();
                        printf("\nPopped item is : %d\n",x);
                        break;
                case 3:
                        printf("\nItem at the top is %d\n",Top());
                        break;
                case 4:
                        DisplayStack();
                        break;
                case 5:
                        exit(1);
                default :
                        printf("\nWrong choice\n");
				} 
		}
		fclose(f);
}
 
 
