#include <stdio.h>
#include <stdlib.h>

struct Node{
	int data;
	struct Node* pNext; 
}; 
typedef struct Node NODE;

NODE *pTop = NULL; 
NODE *pBelow = NULL; 

/*
-- IsEmpty
-- Push
-- Pop
-- Top
*/

// --IsEmpty 
int IsEmpty(){
	if(pTop == NULL && pBelow == NULL)
		return 1; 
	else
		return 0; 
}

//Push 
void Push(int x){
	NODE *p;
	p= (NODE*)malloc(sizeof(NODE));
	if(p == NULL){
		printf("\nKhong du bo nho de cap phat");
		return; 
	}else  
    {    
        p->data = x;  
        p->pNext = NULL; 
        if(pTop == NULL)  
        {  
            pTop = p;  
            pBelow = p;   
            pTop -> pNext = NULL;  
            pBelow -> pNext = NULL;  
        }  
        else   // behind like q ADDLAST in LinkedList 
        {  
            pBelow -> pNext = p;  
            pBelow = p;  
//            pBelow->pNext = NULL;  
        }  
    }  
} 

//Pop --tuong duong removeHead SLL 
int Pop(){
	int x; 
	if(IsEmpty()){
		printf("Danh sach lien ket rong!\n");
		exit(1); 
	}else{
		NODE *p = pTop;
		x = p->data; 
		pTop = pTop->pNext; 
		free(p);
		return x; 
	}
} 

//Top
int Top(){
	if(IsEmpty()){
		printf("\nStack Underflow\n");
        exit(1);
	}else{
		return pTop->data; //lay gia tri cua ptu dau STACK
	} 
} 

void DisplayQueue(){
	NODE *p;
	p = pTop; 
	if(IsEmpty()){
		printf("\nStack Underflow\n");
        return;
	} 
	while (p!=NULL) 
		{
			printf("%d ",p->data);
			p = p->pNext;
		}
}

int main(){ 
	int x; 
	NODE *p;  
	pTop = NULL; 
    FILE *f = fopen("Q.txt", "r");
    if (f==NULL)
		return 0;
    while (fscanf(f,"%d",&x) != EOF)
    {
//    	p = InitNode(x);
//		GetQueueFromFile(&pTop,p);
		Push(x); 
		printf("%d\n",x);
	}		
 	int choice;
        while(1)
        {
                printf("\n1.Push\n");
                printf("2.Pop\n");
                printf("3.Display item at the top\n");
                printf("4.Display all items of the stack\n");
                printf("5.Quit\n");
                printf("\nEnter your choice : ") ;
                scanf("%d", &choice);

                switch(choice)
                {
                case 1:
                        printf("\nEnter the item to be pushed : ");
                        scanf("%d",&x);
                        Push(x);
                        break;
                case 2:
                        x=Pop();
                        printf("\nPopped item is : %d\n",x);
                        break;
                case 3:
                        printf("\nItem at the top is %d\n",Top());
                        break;
                case 4:
                        DisplayQueue();
                        break;
                case 5:
                        exit(1);
                default :
                        printf("\nWrong choice\n");
				} 
		}
		fclose(f);
}
 
 
