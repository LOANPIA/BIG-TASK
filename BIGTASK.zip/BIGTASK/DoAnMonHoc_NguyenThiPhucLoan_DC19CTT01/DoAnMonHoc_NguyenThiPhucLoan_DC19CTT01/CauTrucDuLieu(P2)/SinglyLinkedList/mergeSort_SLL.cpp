#include <stdio.h>    // printf, scanf
#include <conio.h>    // ham getch
#include <stdlib.h>   // malloc (cap phat vung nho cho 1 n�t)

//CHUONG TRINH DANH SACH LIEN KET DON -- SONGUYEN

typedef struct SoNguyen{
	int data;
	struct SoNguyen *next;
}Node;

int init(Node **head)
{
	*head=NULL;
}
int isEmpty(Node* list) {
    return list == NULL;
}

Node *CreateNode(int x)
{
	Node *p;
	p= (Node*)malloc(sizeof(Node));
	p->data=x;
	p->next=NULL;
	return p;
}

void AddFirst(Node **head, Node *p)
{
	Node *Head = *head;
	if (Head ==NULL )
		Head = p;
	else
	{
		p->next = Head;
		Head = p;
	}
	*head = Head;
}
void AddLast(Node **head, Node *p)
{
	Node *Head = *head;
	if (Head == NULL)
		Head=p;
	else
	{
		Node *q=Head;
		while (q->next!=NULL)
			q=q->next;
		q->next = p;
	}
	*head = Head;
}
void AddMiddle(Node **head, Node *p)
{
	Node *Head = *head; //bien Node gon cho **head  
	if (p->data < Head->data)
		AddFirst(&Head,p);
	else
	{
		Node *q = Head;
		Node *t;
		while (q->next != NULL && q->data < p->data)
		{
			t = q;
			q = q->next;
		}
		if (q->next==NULL)
			AddLast(&Head,p);
		else
			{
				p->next = t->next; //p->next=  q;
				t->next= p;
			}
	}
	*head = Head;
}

void removeHead(Node **head) {
    if(isEmpty(*head)) {
        printf("Danh sach lien ket rong!\n");
    } else {
        Node* p = *head;
        (*head) = (*head)->next;
        free(p);
        printf("\nXoa node head thanh cong!\n");
    }
}
void removeTail(Node **head) {
    if(isEmpty(*head)) {
        printf("Danh sach lien ket rong!\n");
    } else {
        if((*head)->next == NULL) {
            free(*head);
            *head = NULL;
        } else {
            Node* p = *head;
            while (p->next->next != NULL) {
                p = p->next;
            }
            free(p->next);
            p->next = NULL;
        }
        printf("\nXoa node tail thanh cong!\n");
    }
}
void removeMiddle(Node **head){
	if(isEmpty(*head)){
		printf("Danh sach lien ket rong!\n");
	}else{
	if((*head)->next == NULL){
		free(*head);
		*head = NULL;
		}else{
			Node* p = *head;
			Node* q = *head;
			Node* t = NULL; 
			while(q != NULL && p->next != NULL){
				q = q->next->next;
				t = p;
				p = p->next; 
			}
			t->next = p->next;
			printf("\nXoa node mid thanh cong!\n");
		}
	}
}

void getMid(Node *head){
//	if(head == NULL || head->next == NULL){
//		return head;
//	}
	Node* p = head;
	Node* q = head->next;
//	Node *p, *q;
//	p = q = head; 
	if(head != NULL){
	while(q->next != NULL){ //q,p p->next != NULL  
		p = p->next;
		q = q->next->next; 
	}
//	return p;
	printf("\nNode middle : %d\n", p->data); 
	}
}

void tach(Node *head, Node **a, Node **b){
//	Node *mid = getMid(head);
//	a = head;
//	b = mid->next;
//	mid->next = NULL; 

	Node *q;
	Node *p;
	p = head;
	q = head->next;
	
	while(q != NULL){
		q = q->next;
		if(q != NULL){
			p = p->next;
			q = q->next; 
		} 
	} 
	
	*a = head;
	*b = p->next;
	p->next = NULL; 
} 
Node* merge(Node *a, Node *b){
	if(a==NULL){
		return b; 
	} 
	else if(b==NULL){
		return a; 
	} 
	Node *result = NULL;
	
	if(a->data < b->data){
		result = a;
		result->next = merge(a->next,b); 
	} else {
		result = b;
		result->next = merge(a,b->next); 
	} 
	return (result); 
} 
void mergeSort(Node **head){
	Node *Head = *head; 
	Node *a = NULL;
	Node *b = NULL; 
	if((*head) == NULL || (*head)->next == NULL){
		return; 
	} 
	tach(*head, &a, &b); 
	mergeSort(&a);
	mergeSort(&b);
	*head = merge(a,b); 	
} 


// Find and Update Node (Value X into Value Y)
int updateX(Node **head, const int nodex, const int y){
	Node *p = *head;
	int countUpdate = 0; // khong tim thay X -> khong update duoc
	while(p!=NULL){
		if(p->data == nodex){
			p->data = y;
			countUpdate++; 
		} 
		p = p->next; 
	} 
	return countUpdate;   
} 

//hien thi list dao nguoc 
void reverse_print(Node *head) {
   while(head == NULL) {
      printf("[null] => ");
      return;
   }
   reverse_print(head->next);
   printf(" %d =>",head->data);
   
}
void PrintList(Node *head)
{
	Node *p;
	p=head;
	while (p!=NULL) 
		{
			printf("%d ",p->data);
			p = p->next;
		}
}

int main()
{
	FILE *f;
	f = fopen("SoNguyen.txt","r")	;
	if (f==NULL)
		return 0;
	int x;
	Node *head; 
	init(&head);
	Node *p;	
	while (fscanf(f,"%d",&x)!=EOF)
	{
		p = CreateNode(x);
		AddLast(&head,p);
	}
	x=1;
	p= CreateNode(x);
	AddFirst(&head,p);
	x=15;
	p= CreateNode(x);
	AddLast(&head,p);
	x=7;
	p= CreateNode(x);
	AddMiddle(&head,p);
	
	x=23;
	p= CreateNode(x);
	AddFirst(&head,p);
	x=4;
	p= CreateNode(x);
	AddLast(&head,p);
//	x=51;
//	p= CreateNode(x);
//	AddFirst(&head,p); //so lon khong kha quan 
	
	PrintList(head);
	
	removeHead(&head);
    printf("Danh Sach Sau Khi Xoa Head: \n");
    PrintList(head);
    removeMiddle(&head);
	printf("Danh sach lien ket sau khi xoa mid: \n");
   	PrintList(head);
    removeTail(&head);
    printf("Danh sach lien ket sau khi xoa tail: \n");
    PrintList(head);
 
    getMid(head);

	mergeSort(&head);
	printf("\nDanh sach lien ket sau khi sap xep tron: \n");  
	PrintList(head);  
  
  	int nodex, y; 
  	printf("\nNhap gia tri node X can cap nhat: ");
	scanf("%d",&nodex); 
	printf("\nNhap gia tri node Y cap nhat vao X: "); 
	scanf("%d",&y); 
	
	int UpdateResult = updateX(&head, nodex, y); 
	UpdateResult == 0 ? printf("Khong tim thay X. Cap nhat that bai!") 
	: printf("Tim thay va Cap nhat X thanh cong!\n"); 
	printf("\nDanh sach hien tai sau khi cap nhat: "); 
	PrintList(head);
	
	printf("\nDay la danh sach lien ket dao nguoc: ");
	reverse_print(head); 
	 
	fclose(f);
}
