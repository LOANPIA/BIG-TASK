#include <stdio.h>
#include <conio.h>
#include <stdlib.h> 
#include <stdlib.h>
#include <string.h>
typedef struct VanBan{
 char data;
 struct VanBan *next;
}Node;

int init(Node **head) //KHOI TAO NODE DAU VA CHO NODE DAU R?NG
{
    *head=NULL;
}
int isEmpty(Node *list) { //Kiem tra danh sach rong
    return list == NULL;
}

Node *CreateNode(int x)
{
 Node* p;
 p= (Node*)malloc(sizeof(Node));
 p->data=x;
 p->next=NULL;
 return p;
}
void ThemCuoi(Node** head, Node *p)
{
 Node *Head = *head;
 if (Head == NULL)
  Head=p;
 else
 {
  Node *q=Head;
  while (q->next!=NULL)
   q=q->next;
  q->next = p;
 }
 *head = Head;
}

//int XuongDong(Node **head){
//	char demxuongdong = 0;
//	Node *p = *head;
//	while(p!=NULL){
//		//ch = p->data; 
//		// TITV\n\0 => TITV\0\0
//		if(p->data ='\n'){
//			//p->data=='\0';
//			printf("Ky tu xuong dong xuat hien: %c lan",p->data);
////			printf("Ky tu xuong dong co: %c cai",p->data);
//			demxuongdong++;
//		}
//	}
////	p=p->next; 
//	return demxuongdong;
//}

//void count(FILE *f,int *c,int *line)
//{
//  char ch;
//  do
//    {
//      ch=getc(f);
//      if(ch!=' ' && ch!='\n' && ch!=EOF) (*c)++;
//      if(ch=='\n') (*line)++;
//    }  while(ch!=EOF);
//}

bool VietHoaKyTu(Node **head, const int ox, const int y){
 Node *p = *head;
 int countUpdate = 0; // khong tim thay X -> khong update duoc
 while(p!=NULL){
   if(p->data >= 97 && p->data <= 122){
    p->data = p->data - 32;
    countUpdate++; 
   }else{
    if(p->data >= 65 && p->data <= 90)
     p->data = p->data + 32;
   } 
   p = p->next; 
 } 
 return countUpdate;
} 


int XuongDong(Node **head){
	int demxuongdong = 0;
	Node *p = *head;
	while(p!=NULL){
		if(p->data!=' '||p->data!='\n'||p->data!='\t'){
			demxuongdong++;
			printf("Ky tu xuong dong xuat hien: %d lan",demxuongdong);
		}
	}
	return demxuongdong;
}


//duoc roi bbi
void PrintList(Node *head)
{
 Node *p;
 p=head;
 while (p!=NULL) 
  {
   printf("%c ",p->data);
   p = p->next;
  }
}

int main()
{
 FILE *f;
 f = fopen("textCountEnterLine.txt","r") ;
 if (f==NULL)
  return 0;
 int x;
 Node *head; 
 init(&head);
 Node *p; 
 while (fscanf(f,"%c",&x)!=EOF)
 {
  p = CreateNode(x);
  ThemCuoi(&head,p);
 }
PrintList(head);
//        char nox,ny;
//         demXD(&head,nox,ny); 
//        printf("\nDanh sach hien tai sau khi cap nhat: "); 
//        PrintList(head);
        
//char ch; 
//int line = 0; 
// while((p->data=fgetc(f))!=EOF) {
//      if(p->data='\n'){
//         line++;
//    	}	 
//   }
//   //close the file
   
   XuongDong(&head);
   fclose(f);
//   //print number of lines
//   printf("Total number of lines are: %d\n",line);
//   return line;
}
