#include <stdio.h>
#include <conio.h>
#include <stdlib.h> 
#include <stdlib.h>
typedef struct VanBan{
 char data;
 struct VanBan *next;
}Node;

int init(Node **head)
{
 *head=NULL;
}
int isEmpty(Node* list) {
    return list == NULL;
}

Node *CreateNode(int x)
{
 Node *p;
 p= (Node*)malloc(sizeof(Node));
 p->data=x;
 p->next=NULL;
 return p;
}
void ThemCuoi(Node **head, Node *p)
{
 Node *Head = *head;
 if (Head == NULL)
  Head=p;
 else
 {
  Node *q=Head;
  while (q->next!=NULL)
   q=q->next;
  q->next = p;
 }
 *head = Head;
}
bool VietHoaKyTu(Node **head, const int ox, const int y){
 Node *p = *head;
 int countUpdate = 0; // khong tim thay X -> khong update duoc
 while(p!=NULL){
   if(p->data >= 97 && p->data <= 122){
    p->data = p->data - 32;
    countUpdate++; 
   }else{
    if(p->data >= 65 && p->data <= 90)
     p->data = p->data + 32;
   } 
   p = p->next; 
 } 
 return countUpdate;   
} 

int CountEnterLine(Node **head){
	Node *p = *head; 
	int demXD = 0;
	//char x = '\n'; 
	while(p!=NULL){
		if(p->data == '\n'){
			demXD++; 
		} 
		p=p->next; 
	} 
	return demXD; 
} 
void PrintList(Node *head)
{
 Node *p;
 p=head;
 while (p!=NULL) 
  {
   printf("%c ",p->data);
   p = p->next;
  }
}

int main()
{
 FILE *f;
 f = fopen("textCountEnterLine.txt","r") ;
 if (f==NULL)
  return 0;
 int x;
 Node *head; 
 init(&head);
 Node *p; 
 while (fscanf(f,"%c",&x)!=EOF)
 {
  p = CreateNode(x);
  ThemCuoi(&head,p);
 }
PrintList(head);
		char ox,y;
 		VietHoaKyTu(&head,ox,y); 
        printf("\nDanh sach hien tai sau khi cap nhat: "); 
        PrintList(head);
        int demxuongdong = CountEnterLine(&head); 
        printf("\nSo lan xuat hien ky tu xuong dong: %d",demxuongdong); 
fclose(f);
}
