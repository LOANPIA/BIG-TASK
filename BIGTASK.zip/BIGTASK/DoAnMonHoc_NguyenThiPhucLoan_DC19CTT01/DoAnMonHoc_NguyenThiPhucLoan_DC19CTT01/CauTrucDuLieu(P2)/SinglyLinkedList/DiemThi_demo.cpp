#include <stdio.h>    // printf, scanf
#include <conio.h>    // ham getch
#include <stdlib.h>   // malloc (cap phat vung nho cho 1 n�t)

//CHUONG TRINH DANH SACH LIEN KET DON -- SONGUYEN

struct SinhVien
{
    char MaSV[50];
    char Ho[200];
    char Ten[150];
    float DiemThi; 
};

struct Node{
	SinhVien data; 
	struct Node* next;
};

struct LIST
{
    Node *head;
    Node *tail;
};

int init(LIST &L)
{
	L.head=L.tail=NULL;
}
//int isEmpty(Node* list) {
//    return list == NULL;
//}

Node *CreateNode(SinhVien x)
{
	Node *p;
	p= (Node*)malloc(sizeof(Node));
	p->data=x;
	p->next=NULL;
	return p;
}

void AddLast(LIST &L, Node *p)
{
	 if(L.head==NULL)  L.head=L.tail=p;
    else
    {
        L.tail->next=p;
        L.tail=p;
    }
}

//Find and Print Info 1 follow Id 
void tim (LIST L)
{
    Node *p;
    int dem=0;
    char MaSV[20];
    printf("\nNhap ma sv can tim: ");
    fflush(stdin);
    gets(MaSV);
    p=L.head;
    while (p!=NULL)
    {
        if(strcmp(MaSV,p->data.MaSV)==0)      dem++;
        p=p->next;
    }
    if(dem!=0)
    {
            printf("\nTim thay sv: "); output(p->data);
    }
    else printf("\nKo tim thay.");
}

void PrintList(Node *head)
{
	Node *p;
	p=head;
	while (p!=NULL) 
		{
			printf("%s %s %s %0.2f",p->data);
			p = p->next;
		}
}

int main()
{
	FILE *f;
	f = fopen("DiemThi.txt","r")	;
	if (f==NULL)
		return 0;
	int x;
	Node *head; 
	init(&head);
	Node *p;	
	while (fscanf(f,"%s",&x)!=EOF)
	{
		p = CreateNode(x);
		AddLast(&head,p);
	}
	
	PrintList(head);	
  	Tim(L);
	 
	fclose(f);
}
