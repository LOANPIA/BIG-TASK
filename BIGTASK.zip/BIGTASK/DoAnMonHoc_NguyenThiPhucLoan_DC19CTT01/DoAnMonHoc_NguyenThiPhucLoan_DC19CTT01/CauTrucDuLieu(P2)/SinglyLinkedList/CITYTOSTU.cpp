#include <stdio.h>  // Thu vien inp out  
#include <string.h> // strlen, strcpy, ...
#include <stdlib.h> // H�m exit, atoi, atof
 
#define TRUE 1
#define INVALID_STU_CODE -1

struct Stu{
	int code;
	char name[100];
	float diem; 
}; 
typedef struct Stu Stu;

struct LinkedList{
	Stu stu;
	struct LinkedList *next;  
}; 
typedef struct LinkedList *Node; 

Node initHead(){
	Node head;
	head = NULL;
	return head; 
} 

Node createNode(Stu stu){
	Node temp;
	temp = (Node)malloc(sizeof(struct LinkedList));
	temp->next = NULL;
	temp->stu = stu;
	return temp; 
} 

// Th�m v�o cuoi
Node addTail(Node head, Stu value){
    Node temp,p;// Khai b�o 2 Node tam temp v� p
    temp = createNode(value);
    if(head == NULL){
        head = temp;  
    }
    else{
        p  = head;
        while(p->next != NULL){
            p = p->next;
        }
        p->next = temp;
    }
    return head;
}

// H�m t�ch c�c th�nh phan cua 1 dong trong file
Stu handleLineData(char *line){
    Stu stu;
    stu.code = INVALID_STU_CODE; 
    //const char delimiter1[] = "\t";
    const char delimiter2[] = ",";
    char *tmp;
    tmp = strtok(line, delimiter2);
    if (tmp == NULL) {
        printf("Du lieu khong dung dinh dang: %s", line);
        exit(EXIT_FAILURE);
    }
   stu.code = atoi(tmp);
    int index = 0;
    for (;;index++) {
        tmp = strtok(NULL, delimiter2);
        if (tmp == NULL)
            break;
        if (index == 0){
            stu.code = atoi(tmp);
        }else if (index == 1){
           	strcpy(stu.name, tmp);
        }else if (index == 2){
            stu.diem = (float)atof(tmp);
        }else {
            printf("Du lieu khong dung dinh dang: %s", line);
            exit(EXIT_FAILURE);
        }
    }
    return stu;
}

Node readData(Node head, const char* fileName){
    FILE* file = fopen(fileName, "r");
    if(!file){
        printf("Co loi khi mo file : %s\n", fileName);
        exit(EXIT_FAILURE);
    }
    char line[500];
    while (fgets(line, sizeof(line), file)) {
        Stu stu = handleLineData(line);
        if (stu.code != INVALID_STU_CODE) {
            head = addTail(head, stu);
        }
    }
    fclose(file);
    return head;
}

void traverser(Node head){
    printf("Danh sach hien tai:\n");
    printf("%10s%50s%f\n", "Ma SV", "HOTEN", "DIEM");
    for(Node p = head; p != NULL; p = p->next){
        printf("%10s%50s%0.2f\n", p->stu.code, p->stu.name, p->stu.diem);
    }
}

//Stu createStu(){
//	Stu newStu;
//	printf("\nNhap code: ");
//	scanf("%d", &newStu.code);
//	printf("\nNhap hoten: ");
//	getchar();
//	fgets(newStu.name, 100, stdin);
//	// X�a \n o cuoi chuoi vua nhap neu c�
//    if ((p=strchr(newStu.name, '\n')) != NULL){
//        *p = '\0';
//    }
//    printf("Nhap diem: ");
//    scanf("%f", &newStu.diem);
//    return newStu; 
//} 

//int findIndexByCode(Node head, int code){
//    int index = -1;
//    for(Node p = head; p != NULL; p = p->next){
//        index++;
//        if (p->stu.code == code){
//            return index;
//        }
//    }
//    return -1; // Kh�ng t?m th?y
//}

void printMenu(){
    printf("================== MENU ====================\n");
    printf("1. Duyet danh sach\n");
    printf("2. Them du lieu (them Node)\n");
    printf("3. Sua du lieu (sua Node)\n");
    printf("4. Xoa du lieu (xoa Node)\n");
    printf("5. Tinh tong dien tich\n");
    printf("6. Tim dia chi cua Node co dien tich lon nhat\n");
    printf("7. Tim tinh co dan so lon nhat\n");
    printf("8. Sap xep danh sach theo ma tinh\n");
    printf("9. Sap xep danh sach theo dien tich\n");
    printf("10. Thoat chuong trinh\n");
    printf("============================================\n");
}

int main(){
    Node head = initHead();
    head = readData(head, "DiemThi.txt");
    traverser(head);
//    int option;
//    Stu result;
//    while (TRUE) {
//        printMenu();
//        printf("Nhap lua chon cua ban (1-10): ");
//        scanf("%d", &option);
//        switch(option) {
//            case 1:
//                traverser(head);
//                break;
//            case 2:
//                head = addNode(head);
//                break;
//            case 3:
//                editNode(head);
//                break;
//            case 4:
//                head = removeNode(head);
//                break;
//            case 5:
//                printf("Tong dien tich: %f\n", sumArea(head));
//                break;
//            case 6:
//                printf("Tinh co dien tich lon nhat o vi tri: %d\n", indexOfMaxArea(head) + 1); // v? tr� = ch? s? + 1
//                break;
//            case 7:
//                result = maxByPopulation(head);
//                printf("%s la noi co dien tich lon nhat voi %d nguoi!\n", result.name, result.population);
//                break;
//            case 8:
//                sortCities(head, 1, 0, 0);
//                traverser(head);
//                break;
//            case 9:
//                sortCities(head, 0, 1, 0);
//                traverser(head);
//                break;
//            case 10:
//                printf("Ket thuc chuong trinh!...\n");
//                exit(EXIT_SUCCESS);
//            default:
//                printf("Lua chon khong dung, vui long nhap lai!\n");
//                break;
//        }
//    }
}
