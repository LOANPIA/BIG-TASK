#include <stdio.h> 
#include <string.h>
#include <stdlib.h>

struct SV{
	int ma;
	char hoten[100];
	float diem;
};
typedef struct SV SV;

struct List{
	SV sv;
	struct List *next;
};
typedef struct List *Node;

Node initHead(){
	Node head;
	head = NULL;
	return head;
}

//nh?p h�m handle v�o 

Node createNode(SV sv){
	Node temp;
	temp = (Node)malloc(sizeof(struct List));
	temp->next = NULL;
	temp->sv = sv;
	return temp;
}

Node themCuoi(Node head, SV gtri){
	Node temp,p;
	temp = createNode(gtri);
	if(head == NULL){
		head = temp;
	}else{
		p=head;	
		while(p->next != NULL){
			p = p->next;
		}
		p->	next = temp;
	}
	return head;
}

SV handleLineData(char *line){
	SV sv;
	sv.ma = -1;
	const char kytutab[] = "\t";
	char *tmp;
	tmp = strtok(line, kytutab);
	if (tmp == NULL){
		printf("\ndu lieu khong dung:%s",line);
		exit(-1);
	}
	sv.ma = atoi(tmp);
	int index = 0;
	for (;;index++){
		tmp = strtok(NULL, kytutab);
		if(tmp== NULL)
			break;
		if(index== 0){
			sv.ma = atoi(tmp);
		}else if (index ==1){
			strcpy(sv.hoten, tmp);
		}else if (index ==2){
			sv.diem = (float)atof(tmp);
		}else{
			printf("\ndu lieu khong dung:%s",line);
			exit(EXIT_FAILURE);
		}
		
	}
	return sv;
}

Node readData(Node head, const char* fileName){
	FILE* file = fopen(fileName, "r");
	char line[500];
	while (fgets(line, sizeof(line), file))
	{
		SV sv = handleLineData(line);
		if (sv.ma != -1){
			head = themCuoi(head, sv);
		}
	}
	fclose(file);
	return head;
}

int tim(Node head, int code){
	int index = -1;	
	for(Node p = head; p != NULL; p = p->next){
		index ++;
		if(p->sv.ma==code){
			printf("ma sv: %d\n", p->sv.ma);
			printf("ho ten: %s\n", p->sv.hoten);
			printf("diem thi: %0.2f\n", p->sv.diem);
			return index;
		}
	}
	return -1;
}

void PrintList(Node head)
{
	Node p;
	p=head;
	while(p!= NULL){
			printf("ma sv: %d\n", p->sv.ma);
			printf("ho ten: %s\n", p->sv.hoten);
			printf("diem thi: %0.2f\n", p->sv.diem);
			p=p->next;
	}
}

void printMenu(){
	printf("\nmenu");
	printf("\n1.duyet danh sach");
	printf("\n2. tim ma");
	printf("\n3. thoat chung trinh");
}


int main(){
	Node head = initHead();
	head = readData(head, "diem.txt");
	PrintList(head);
	int luachon;
	SV ketqua;
	while(1){
		printMenu();
		printf("Nhap lua chon cua ban: ");
		scanf("%d", &luachon);
		switch(luachon){
			case 1:
				PrintList(head);
				break;
			case 2:
				int code;
				printf("Nhap ma sv can tim:");
				scanf("%d", &code);
				tim(head,code);
				break;
			case 3:
				printf("ket thuc\n");
				exit(-1);
			default:
				printf("Lua chon sai, nhap lai\n");
				break;
		}
	}
}
