#include<stdio.h>
#include<conio.h>
#include<string.h>
typedef struct {
	char Ma[10];
    char Ho[50];
	char Ten[50];
    float DiemThi; 
} Sinh_Vien;
void Nhap_ds(int *n,Sinh_Vien sv[100])
{
    printf("\nNhap so sinh vien: ");
    scanf("%d",n);
    for(int i=0;i<*n;i++)
    {
        printf("\nNhap thong tin sinh vien: %d",i);
        printf("Nhap Ma: ");
        fflush(stdin);
        gets(sv[i].Ma);
        printf("\nNhap ho: ");
        fflush(stdin);
        gets(sv[i].Ho);
        printf("\nNhap ten: ");
        fflush(stdin);
        gets(sv[i].Ten);
        printf("Nhap diem thi: ");
        scanf("%0.2f",&sv[i].DiemThi);
    }
}
void In_ds(int n,Sinh_Vien sv[100])
{
    printf("\nDANH SACH SINH VIEN");
    printf("\nMa     HO TEN    DiemThi");
    for(int i=0;i<n;i++)
    {
        printf("\n%s\t%s\t%s\t%0.2f",sv[i].Ma,sv[i].Ho,sv[i].Ten,sv[i].DiemThi);
    }
}
void Tim_ds(int n,Sinh_Vien sv[100])
{
    int i=0;
    printf("\nTIM KIEM SINH VIEN");
    char id[50];
    printf("\nNhap ma sinh vien: ");
    fflush(stdin);
    gets(id);
    for(i=0;i<n;i++){
        if(strcmp(sv[i].Ma,id)==0){
        printf("\nDANH SACH SINH VIEN TIM THAY");
        printf("\nMa     HO TEN    DiemThi");
        printf("\n%s\t%s\t%s\t%0.2f",sv[i].Ma,sv[i].Ho,sv[i].Ten,sv[i].DiemThi);
            break; 
        }
    }
    if(i==n){
        printf("Khong tim thay");
    }
}
main()
{
    int c;
    Sinh_Vien sv[100];
    FILE *f = fopen("DiemThi.txt", "r");
    if (f==NULL)
		return 0;
    while (fscanf(f,"\n%s\t%s\t%s\t%0.2f",&x) != EOF)
    {
    	p = InitNode(x);
		In_ds(n,sv);
		//printf("\n%s\t%s\t%s\t%0.2f",x);
	}
    int n;

    while(c!=4){
        printf("\nChon 1: Nhap danh sach sinh vien");
        printf("\nChon 2: Hien thi danh sach sinh vien");
        printf("\nChon3: Tim kiem sinh vien theo Ma");
        printf("\nChon4: Ket thuc");
        printf("\nMoi ban chon: ");
        scanf("%d",&c);
    switch(c){
        case 1:
            Nhap_ds(&n,sv);
            //system("cls");
            break;
        case 2:
            In_ds(n,sv);
            break;
        case 3:
            Tim_ds(n,sv);
            break;
        }
    }
}
