#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

typedef struct node{
	int data;
	struct node *next;	
}Node;

Node *Head=NULL;
Node *TaoNode(int a){
	Node *p = (Node*)malloc(sizeof(Node));
	p->data=a;
	p->next=NULL;
	return p;
}

void TaoDS(){
	int n,a;
	FILE *fin;
	fin = fopen("DiemThi.txt","r");
	char s[255];
	fgets(s,sizeof(s),fin);
	printf("\nChuoi doc duoc tu file: %s\n",s);
	fclose(fin);
	Node *p,*q;
	//printf("Nhap so trong node : ");
	//scanf("%d",&n);
	for(int i=0;i<n;i++){
		printf("Nhap node thu %d : ",i+1);
		scanf("%d",&a);
		p=TaoNode(a);
		if(Head==NULL){
			Head=p;
			q=p;
		}
		else{
			q->next=p;
			q=p;
		}
	}
}
void InDS(){
	Node *p=Head;
	printf("Node trong danh sach : ");
	while(p!=NULL){
		printf("%d ",p->data);
		p=p->next;
	}
}
void ThemDau(){
	int a;
	Node *p;
	printf("\nNhap so can bo sung vao dau danh sach : ");
	scanf("%d",&a);
	p=TaoNode(a);
	p->next=Head;
	Head=p;
}

void ThemCuoi(){
	int a;
	Node *p,*q=Head;
	printf("\nNhap so can bo sung vao cuoi danh sach : ");
	scanf("%d",&a);
	p=TaoNode(a);
	while(q->next!=NULL) q=q->next;
	q->next=p;
}

void XoaDau(){
	Node *p=Head;
	Head=Head->next;
	free(p);
}
void XoaCuoi(){
	Node *p,*q=Head;
	while(q->next!=NULL){
		q=p;
		q=q->next;
	}
	p->next=NULL;
	free(q);

}
void Menu(){
	printf("\n1. Tao danh sach \n");
	printf("2. Them dau danh sach \n");
	printf("3. Them cuoi danh sach \n");
	printf("4. Xoa dau danh sach \n");
	printf("5. Xoa cuoi danh sach \n");
	printf("6. In danh sach \n");
	printf("0. Ket thuc \n");
}
void KetThuc(){
	Node *p;
	if(Head!=NULL){
		while(Head!=NULL){
			p = Head;
			Head=Head->next;
			free(p);
		}
	}
	
}
int main()
{
  Node *p;
  	FILE *fin;
	fin = fopen("DiemThi.txt","r");
	char s[255];
	fgets(s,sizeof(s),fin);
	while (fread(p, sizeof(Node), 1, fin))
	{
		//p = CreateNode(x);
		ThemCuoi();
	}
	InDS();
	int chon;
	
	while(1){
		system("cls");
		Menu();
		printf("Bam chon : ");
		scanf("%d",&chon);
		switch(chon){
			case 1 : TaoDS(); break;
			case 2 : ThemDau(); break;
			case 3 : ThemCuoi(); break;
			case 4 : XoaDau(); break;
			case 5 : XoaCuoi(); break;
			case 6 : InDS(); break;
			case 0 : KetThuc(); break;
		}
	
		
		if(chon==0) break;
		printf("\nNhan phim bat ki de tiep tuc");
		getch();
		
	}
	fclose(fin);
}
