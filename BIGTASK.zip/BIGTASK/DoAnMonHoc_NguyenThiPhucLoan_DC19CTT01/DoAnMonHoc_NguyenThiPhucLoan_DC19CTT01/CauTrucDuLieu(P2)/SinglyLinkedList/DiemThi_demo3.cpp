#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
 
typedef struct tagSINHVIEN {
    int Msv;
    char Hoten[35];
    float diem;
}SINHVIEN, *PSINHVIEN;
 
typedef struct tagNODE {
    SINHVIEN Data;
    tagNODE* Next;
}NODE, *PNODE;
 
typedef struct tagLIST {
    NODE* Dau;
    NODE* Cuoi;
}LISTSV, *PLIST;
 
//Khoi tao NODE
NODE* KhoitaoNode()
{
    NODE* x = (NODE*)malloc(sizeof(NODE));
    if(x == NULL)
    {
        printf("\n Bo nho khong du ");
        return 0;
    }
    x->Next = NULL;
    return x;
}
 
//Khoi tao danh sach LISTSV
void KhoitaoList(LISTSV* x)
{
    x->Dau = NULL;
    x->Cuoi=NULL;
}
 
//in sinh vien
void InSV(NODE* p)
{
    printf("\nMa Sinh vien: %d   ",p->Data.Msv);
    printf("\tTen Sinh vien: %s  ",p->Data.Hoten);
    printf("\nNgay/ Thang/ Nam sinh: %5d/%5d/%5d   ", p->Data.ngay, p->Data.thang, p->Data.nam);
    printf("\nDiem Toan: %.2f   ", p->Data.Toan);
    printf("\tDiem Van: %.2f   ", p->Data.Van);
    printf("\tDiem tong ket: %.2f\n\n\n", p->Data.TK);
}
 
// in danh sach SINHVIEN
void InDanhSach(LISTSV x)
{
    NODE *p;
    p = x.Dau;
    while(p != NULL)
    {
        InSV(p);
        p = p->Next;
    }
}
 
//Them mot NODE vao Cuoi danh sach
void ThemCuoi(LISTSV* x, NODE* t)
{
    if(x->Dau == NULL)
    {
        x->Dau = t;
    }
   else
   {
       x->Cuoi->Next = t;
   }
   x->Cuoi = t;
}
 
//Tim kiem theo Ma sinh vien
void TimKiem(LISTSV x , int n)
{
    NODE *p;
    p = x.Dau;
    while(p != NULL)
    {
        if(p->Data.Msv == n)
        {
            InSV(p);
        }else   printf("\n Khong co sinh vien dat tieu chuan can tim\n");
        p = p->Next;
    }
}
 
//Giai phong bo nho
void giaiphong(LISTSV *x)
{
    NODE *p = x->Dau;
    NODE *a;
   while( p->Next != NULL)
    {
        a = p;
        p = p->Next;
        free(a);
    }
}
 
 
//Ham Tao Danh Sach Tuy chon
int Menu()
{
    int a;
    int Ma;
    LISTSV x;
    KhoitaoList(&x);
    do
    {
        printf("\n Ban chon 1,2,3,4,5");
        printf("\n\nNhap so can chon roi bam enter");
        printf("\n\n\n 1 - Nhap danh sach Sinh Vien");
        printf("\n 2 - Liet ke danh sach Sinh Vien");
        printf("\n 3 - Tim kiem Sinh vien theo ma Hang");
        printf("\n 4 - Liet ke danh sach Sinh Vien dat loai gioi");
        printf("\n 5 - Liet ke danh sach Sinh Vien dat loai Kha");
        printf("\n 6 - Liet ke danh sach Sinh Vien Phai thi lai");
        printf("\n 7 - Tong So Sinh Vien Phai Hoc lai");
        printf("\n 8 - Liet ke cac sinh vien sinh vao thang 10:");
        printf("\n 9 - Xoa Sinh Vien theo Ma Sinh Vien");
        printf("\n 0 - Thoat\n");
        scanf("%d",&a);
        switch(a)
        {
            case 1:
                {
                    int n;
                    printf("\nNhap so luong Sinh vien : ");
                    scanf("%d",&n);
                    for(int i = 1; i <= n ;i++)
                    {
                        printf("\nNhap Don vi Sinh vien thu: %d \n",i);
                        NhapSV(&x);
                    }
                    break;
                }
            case 2:
                {
                    InDanhSach(x);
                    break;
                }
            case 3:
                {
                    fflush(stdin);
                    printf("\nNhap Ma Sinh Vien can tim:");
                    scanf("%d",&Ma);
                    TimKiem(x ,Ma);
                    break;
                }  
            case 4:
                {
                    inSVGioi(x);
                    break;
                }
            case 5:
                {
                    inSVKha(x);
                    break;
                }
            case 6:
                {
                    inSVThilai(x);
                    break;
                }
            case 7:
                {
                    SVHocLai(x);
                    break;
                }
            case 8:
                {
                    inSV10(x);
                    break;
                }
            case 9:
                {
                    fflush(stdin);
                    printf("\nNhap Ma Sinh Vien Xoa:");
                    scanf("%d",&Ma);
                    fflush(stdin);
                    XoaSV(&x ,Ma);
                    break;
                }
            case 0:
                {
                    break;
                }
            default: printf("\nBan chon sai vui long chon lai!");
        }
    }while(a != 0);
    giaiphong(&x);
    return 1;
}
int main()
{
    FILE *f;
	f = fopen("DiemThi.txt","r")	;
	if (f==NULL)
		return 0;
	int x;
	Node *head; 
	init(&head);
	Node *p;	
	while (fscanf(f,"%s",&x)!=EOF)
	{
		p = CreateNode(x);
		AddLast(&head,p);
	}
	
	PrintList(head);	
    Menu();
    clrscr();
    return 0;
}
