#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
 
 
struct SinhVien{
	char Ma; 
    char Ho;
    char Ten;
    float dT;
};
typedef struct SinhVien SV;
 
//1NODE
struct Node{
	SV data;
	struct Node *next; 
}; 
typedef struct Node NODE; 

//LIST
struct List{
	NODE *head;
	NODE *tail; 
};
typedef struct List LIST; 

//InitList 
void InitList(LIST &L){
	L.head = L.tail = NULL; 
} 

//InitNode 
NODE *InitNode(SV x){
	NODE *p;
	p= (Node*)malloc(sizeof(Node));
	if(p == NULL){
		printf("Cap nhat thai bai");
		return NULL; 
	} 
	p->data = x;
	p->next = NULL;
	return p; 
} 

//ADDFirst 
void ThemSVdauDS(LIST &L, NODE *p){
	if(L.head == NULL){
		L.head = L.tail = p; 
	}else{
		p->next = L.head;
		L.head = p; 
	} 
} 

//ADDLast
void ThemSVcuoiDS(LIST &L, NODE *p){
	if(L.head == NULL){
		L.head = L.tail = p; 
	}else{
		L.tail->next = p;
		L.tail = p; 
	} 
} 

//Function Read File from DiemThi.txt
void READ1INFOFROMFILE(SV L[], int &n){
	FILE *f;
	f = fopen("DiemThi.txt", "r");
	if(f==NULL){
		printf("\nLoi moi file de doc!");
		return;
	}
	fread(&n, sizeof(n), 1, f);
	for(int i=0; i<n; i++){
		fread(&L[i], sizeof(SV), 1, f);
	}
	fclose(f);
}

void Xuat(SV){
	printf("\nMa SV: %s",SV.Ma); 
	printf("\nHo va Ten: %s %s",SV.Ho,SV.Ten); 
	printf("\nDiem thi sinh vien: %0.2f",SV.DiemThi); 
} 

int main(){
	SV L[100];
	int n; 
	READ1INFOFROMFILE(L,n);
	Xuat(L);
	return 0; 
} 
