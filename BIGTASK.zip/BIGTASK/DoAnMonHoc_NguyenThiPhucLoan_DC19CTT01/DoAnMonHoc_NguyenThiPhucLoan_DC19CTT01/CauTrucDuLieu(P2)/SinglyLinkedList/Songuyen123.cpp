#include <stdio.h> 
#include <conio.h> 
#include <stdlib.h> 

typedef struct SoNguyen{ //KHOI TAO CAU TRUC NODE VOI DINH DANG SO NGUYEN
    int data; //SO NGUYEN CO GIA TRI INTEGER
    struct SoNguyen*next; //NODE NEXT THEO DUNG CAU TRUC 
}Node;

int init(Node **head) //KHOI TAO NODE DAU VA CHO NODE DAU R?NG
{
    *head=NULL;
}
int isEmpty(Node *list) { //Kiem tra danh sach rong
    return list == NULL;
}

Node *TaoNode(int x) //tao mot ham node va cap phat bo nho cho node de xac dinh luong
{
    Node* p;
    p= (Node*)malloc(sizeof(Node));
    p->data=x; //gia tri node p = gia tri x nhap vao
    p->next=NULL; //node next khi node moi them vao = rong
    return p; //tra ve gia tri node p
}
void Themcuoi(Node** head, Node *p) //ham day node them cuoi 
{
    Node *Head = *head; //kiem tra node dau co hay chua co
    if (Head == NULL)
        Head=p;
    else
    {
        Node *q=Head;
        while (q->next!=NULL) //vong lap de kiem tra gan node den cuoi (null)
            q=q->next;
        q->next = p;
    }
    *head = Head;
}
void Print(Node *head) //hien thi danh sach
{
    Node *p;
    p=head;
    while (p!=NULL) 
        {
            printf("%d ",p->data);

            p = p->next;
        }
}

int demso_Node(Node **head, int x){ //dem so luong so nguyen trong danh sach
    int dem = 0;
    Node *p = *head;
    while(p!=NULL)
    {
            dem++; 
            p=p->next;
        }
    return dem;
}

int main()
{
    FILE *f; 
    f = fopen("songuyen.txt","r")    ;
    if (f==NULL)
        return 0;
    int x;
    Node *head; 
    init(&head);
    Node *p;
    while (fscanf(f,"%d",&x)!=EOF) //vong lap den cuoi 
    {
        p = TaoNode(x);
        Themcuoi(&head,p);
    }
    Print(head);
    int demso = demso_Node(&head,x); //ham in so luong so 
    printf("co tat ca la : %d so " ,demso);
    fclose(f); //dong file
}
