#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct SV{
	int ma;
	char hoten[100];
	float diem; 
}; 
typedef struct SV SV;

struct List{
	SV sv;
	struct List *next;  
}; 
typedef struct List *Node; 

Node initHead(){
	Node head;
	head = NULL;
	return head; 
} 

Node createNode(SV sv){
	Node temp;
	temp = (Node)malloc(sizeof(struct List));
	temp->next = NULL;
	temp->sv = sv;
	return temp; 
} 


Node themCuoi(Node head, SV gtri){
    Node temp,p;
    temp = createNode(gtri);
    if(head == NULL){
        head = temp;  
    }
    else{
        p  = head;
        while(p->next != NULL){
            p = p->next;
        }
        p->next = temp;
    }
    return head;
}

//Ham xet tach ky tu dac biet 
SV handleLineData(char *line){
    SV sv;
    sv.ma = -1; 
    const char kytudb[] = ",";
    char *tmp;
    tmp = strtok(line, kytudb);
    if (tmp == NULL) {
        printf("Du lieu khong dung dinh dang: %s", line);
        exit(-1);
    }
   sv.ma = atoi(tmp);
    int index = 0;
    for (;;index++) {
        tmp = strtok(NULL, kytudb);
        if (tmp == NULL)
            break;
        if (index == 0){
            sv.ma = atoi(tmp);
        }else if (index == 1){
           	strcpy(sv.hoten, tmp);
        }else if (index == 2){
            sv.diem = (float)atof(tmp);
        }else {
            printf("Du lieu khong dung dinh dang: %s", line);
            exit(EXIT_FAILURE);
        }
    }
    return sv;
}

Node readData(Node head, const char* fileName){
    FILE* file = fopen(fileName, "r");
//    if(!file){
//        printf("Co loi khi mo file : %s\n", fileName);
//        exit(-1);
//    }
    char line[1000];
    while (fgets(line, sizeof(line), file))
	{
		SV sv = handleLineData(line);
        if (sv.ma != -1) {
            head = themCuoi(head, sv);
        }
	}
    fclose(file);
    return head;
}

int tim(Node head, int code){
    int index = -1;
    for(Node p = head; p != NULL; p = p->next){
        index++;
        if (p->sv.ma == code){
        	printf("Ma SV: %d\n", p->sv.ma);
			printf("Ho ten: %s\n", p->sv.hoten);
			printf("Diem thi: %0.2f\n", p->sv.diem); 
            return index;
        }
    }
    return -1; // Kh�ng tim thay
}

void PrintList(Node head)
{
	Node p;
	p=head;
	while (p!=NULL) 
		{
			printf("Ma SV: %d\n", p->sv.ma);
			printf("Ho ten: %s\n", p->sv.hoten);
			printf("Diem thi: %0.2f\n", p->sv.diem);
			p = p->next;
		}
}

void printMenu(){
    printf("================== MENU ====================\n");
    printf("1. Duyet danh sach\n");
    printf("2. TimMa\n");
    printf("3. Thoat chuong trinh\n");
    printf("============================================\n");
}

int main(){
    Node head = initHead();
    head = readData(head, "diemThidauphay.txt");
    PrintList(head);
    int luachon;
    SV ketqua;
    while (1) {
        printMenu();
        printf("Nhap lua chon cua ban: ");
        scanf("%d", &luachon);
        switch(luachon) {
            case 1:
                PrintList(head);
                break;
            case 2:
            	int code; 
            	printf("Nhap Ma SV can tim: ");
				scanf("%d", &code);
            	tim(head,code);
                break;
            case 3:
                printf("Ket thuc chuong trinh!...\n");
                exit(-1);
            default:
                printf("Lua chon khong dung, vui long nhap lai!\n");
                break;
        }
    }
}
