#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
#define TRUE 1
#define INVALID_STU_CODE -1

struct Stu{
	int ma;
	char hoten[100];
	float diem; 
}; 
typedef struct Stu Stu;

struct List{
	Stu stu;
	struct List *next;  
}; 
typedef struct List *Node; 

Node initHead(){
	Node head;
	head = NULL;
	return head; 
} 

Node createNode(Stu stu){
	Node temp;
	temp = (Node)malloc(sizeof(struct List));
	temp->next = NULL;
	temp->stu = stu;
	return temp; 
} 

// Th�m v�o cuoi
Node addTail(Node head, Stu value){
    Node temp,p;// Khai b�o 2 Node tam temp v� p
    temp = createNode(value);
    if(head == NULL){
        head = temp;  
    }
    else{
        p  = head;
        while(p->next != NULL){
            p = p->next;
        }
        p->next = temp;
    }
    return head;
}

Stu handleLineData(char *line){
    Stu stu;
    stu.ma = INVALID_STU_CODE; 
    const char delimiter1[] = "\t";
    char *tmp;
    tmp = strtok(line, delimiter1);
    if (tmp == NULL) {
        printf("Du lieu khong dung dinh dang: %s", line);
        exit(EXIT_FAILURE);
    }
   stu.ma = atoi(tmp);
    int index = 0;
    for (;;index++) {
        tmp = strtok(NULL, delimiter1);
        if (tmp == NULL)
            break;
        if (index == 0){
            stu.ma = atoi(tmp);
        }else if (index == 1){
           	strcpy(stu.hoten, tmp);
        }else if (index == 2){
            stu.diem = (float)atof(tmp);
        }else {
            printf("Du lieu khong dung dinh dang: %s", line);
            exit(EXIT_FAILURE);
        }
    }
    return stu;
}

Node readData(Node head, const char* fileName){
    FILE* file = fopen(fileName, "r");
    if(!file){
        printf("Co loi khi mo file : %s\n", fileName);
        exit(EXIT_FAILURE);
    }
    char line[1000];
    while (fgets(line, sizeof(line), file))
	{
		Stu stu = handleLineData(line);
        if (stu.ma != INVALID_STU_CODE) {
            head = addTail(head, stu);
        }
	}
    fclose(file);
    return head;
}

int findIndexByCode(Node head, int code){
    int index = -1;
    for(Node p = head; p != NULL; p = p->next){
        index++;
        if (p->stu.ma == code){
        	printf("Ma SV: %d\n", p->stu.ma);
			printf("Ho ten: %s\n", p->stu.hoten);
			printf("Diem thi: %0.2f\n", p->stu.diem); 
            return index;
        }
    }
    return -1; // Kh�ng tim thay
}

void PrintList(Node head)
{
	Node p;
	p=head;
	while (p!=NULL) 
		{
			printf("Ma SV: %d\n", p->stu.ma);
			printf("Ho ten: %s\n", p->stu.hoten);
			printf("Diem thi: %0.2f\n", p->stu.diem);
			p = p->next;
		}
}

void printMenu(){
    printf("================== MENU ====================\n");
    printf("1. Duyet danh sach\n");
    printf("2. TimMa\n");
    printf("3. Thoat chuong trinh\n");
    printf("============================================\n");
}

int main(){
    Node head = initHead();
    head = readData(head, "DiemThi.txt");
    PrintList(head);
    int option;
    Stu result;
    while (TRUE) {
        printMenu();
        printf("Nhap lua chon cua ban: ");
        scanf("%d", &option);
        switch(option) {
            case 1:
                PrintList(head);
                break;
            case 2:
            	int code; 
            	printf("Nhap Ma SV can tim: ");
				scanf("%d", &code);
            	findIndexByCode(head,code);
                break;
            case 3:
                printf("Ket thuc chuong trinh!...\n");
                exit(EXIT_SUCCESS);
            default:
                printf("Lua chon khong dung, vui long nhap lai!\n");
                break;
        }
    }
}
