#include <stdlib.h>
#include <stdio.h>
#include <string.h>
struct node
{
    int maSV;
    char firstName[100];
	char name[100];
	float diemThi; 
    struct node *next;
};
// function to display linked list
void displayLinkedList(struct node *root)
{
    struct node *temp = root;
    printf("\nLinkedList: ");
    while(temp!=NULL)
    {
        printf("Ma SV: %d",temp->maSV);
        printf("Ho Ten: %s %s",temp->firstName, temp->name);
		printf("Diem Thi: %0.2f",temp->diemThi); 
        temp = temp->next;
    }
    printf("NULL\n\n");
}
// insert node at the beginning of the linked list
struct node* insertAtBegin(node *head, int maSV, char *name)
{
    
    struct node *ptr;
    struct node *temp = (struct node *)malloc(sizeof(struct node));
    temp->maSV = maSV;
    strcpy(temp->name, name);
    temp->next = NULL;
    
    if(head==NULL)
    {
        head = temp;    
    }
    else 
    {
        temp->next = head;
        head = temp;
    }    
    
    return head;
    
}
// function to write linked list to a file
void writeLinkedList(char filename[], node* head){
    
    struct node* temp = head;
    
    FILE* file;
    file = fopen (filename, "w");
    if (file == NULL)
    {
        fprintf(stderr, "\nCouldn't Open File'\n");
        exit (1);
    }
    
    // writing all the nodes of the linked list to the file
    while(temp!=NULL)
    {
        fwrite(temp, sizeof(struct node), 1, file);
        temp = temp->next;
    }
    
    if(fwrite != 0)
    {
        printf("Linked List stored in the file successfully\n");
    }
       else
    {
           printf("Error While Writing\n");
    }
    
    fclose(file);
    
}
struct node* readLinkedList(char filename[]){
    
    struct node* temp = (struct node *)malloc(sizeof(struct node));;
    struct node* head; // points to the first node of the linked list in the file
    struct node* last; // points to the last node of the linked list in the file
    last = head = NULL;
    
    FILE* file;
    file = fopen (filename, "r");
    if (file == NULL)
    {
        fprintf(stderr, "\nCouldn't Open File'\n");
        exit (1);
    }
    
    // reading nodes from the file
    // nodes are read in the same order as they were stored
    // we are using the data stored in the file to create a new linked list
    while(fread(temp, sizeof(struct node), 1, file))
    {
        
        if(head==NULL)
        {
            head = last = (struct node *)malloc(sizeof(struct node));
        }
        else
        {
            last->next = (struct node *)malloc(sizeof(struct node));
            last = last->next;
        }
        last->maSV = temp->maSV;
        strcpy(last->firstName, temp->firstName);
        strcpy(last->name, temp->name);
        last->diemThi = temp->diemThi; 
        last->next = NULL;
        
    }
    
    fclose(file);
    
    return head;
    
}
int main() {
    struct node *head = NULL;
    head = insertAtBegin(head,19574802010001,"Tran","Anh",2.0);
    head = insertAtBegin(head,19574802010002,"Tran","Binh",5.0);
    head = insertAtBegin(head,19574802010003,"Pham","My",3.0);
    
    displayLinkedList(head);
    writeLinkedList("infoFRAME.txt", head);
    
    printf("\nReading Linked List from the file!!\n");
    struct node* newHead = readLinkedList("infoFRAME.txt");
    printf("\nPrint the New Linked List\n");
    displayLinkedList(newHead);
}
