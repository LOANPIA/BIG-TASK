#include<stdio.h>
#include<stdlib.h>

typedef struct BST
{
    int data;
    struct BST *Left;
    struct BST *Right;

}Node;

Node *root = NULL; //nut goc

/*
--CHUONG TRINH CAY NHI PHAN TIM KIEM [LOANPIA]
			DUYET CAY VOI NUT BAT DAU LA NUT GOC (THU TU TRUOC) 
*/


void insertNode(int x);
void preOrderPrint(Node *root);
Node * findMinimum(Node *root);
Node * deleteNode(Node *root, int x);
void search(const Node *root, int val);

void search(const Node *root, int val)
{
    if (!root) {
        printf("%d Khong ton tai.\n", val);
    } else if (val < root->data) {
        search(root->Left, val);
    } else if (val > root->data) {
        search(root->Right, val);
    } else {
        printf("%d Ton tai.\n", val); 
    }
}

int main()
{
	int a;
    FILE *fin = fopen("BST.bin", "rb");
    if (fin==NULL)
		return 0;
    while (fscanf(fin,"%d",&a) != EOF)
    {
    	insertNode(a); 
//		printf("%d\n",a);
	}
//	  insertNode(15);    insertNode(13);
//	  insertNode(5);     insertNode(16);
//	  insertNode(3);     insertNode(20);
//	  insertNode(12);    insertNode(18);
//	  insertNode(10);    insertNode(23);

    printf("\nThu tu cay nhi phan tim kiem theo nut goc dau tien:\n");
    preOrderPrint(root);
    puts("");
  
  	int val; 
	printf("Give a number to search: ");
    scanf("%d", &val);
    search(root, val);
                
	int x;
    printf("\nNhap nut can xoa: ");
    scanf("%d",&x);
    root = deleteNode(root, x);

	printf("\nSau khi xoa__ ");
    printf("\nThu tu cay nhi phan tim kiem theo nut goc dau tien:\n");
    preOrderPrint(root);
    puts("");

    return 0;
}

Node * deleteNode(Node *currentNode, int x)
{
    if(currentNode==NULL) // empty tree -- tra ve cay
        return NULL;
    else if(x < currentNode->data) // value is less than node's number. so go to left subtree -- gia tri nho thi chay qua trai
        currentNode->Left = deleteNode(currentNode->Left, x);
    else if(x > currentNode->data) // value is greater than node's number. so go to right subtree -- gia tri lon thi chay qua phai
        currentNode->Right = deleteNode(currentNode->Right, x);
    else // node found. Let's delete it! --node duoc tim thay va bat dau tien trinh xoa
    {
        //node has no child -- truong hop node xoa khong co 2 node con(node leaf)
        if(currentNode->Left == NULL && currentNode->Right == NULL)
        {
            currentNode = NULL;
        }
        else if(currentNode->Left == NULL) // node has only right child -- Node chi co node con phai
        {
            currentNode = currentNode->Right;
        }
        else if(currentNode->Right == NULL) // node has only left child -- Node chi co node con trai
        {
            currentNode = currentNode->Left;
        }
        else // node has two children -- Node co 2 node con
        {
            Node *tempNode = findMinimum(currentNode->Right); //--timMin cua cay con phai dong nghia la no co the the mang cho Node parent can xoa (co truong hop tim MaxRight cung duoc)
            currentNode->data = tempNode->data;
            currentNode->Right = deleteNode(currentNode->Right, tempNode->data);
        }

    }

    return currentNode;
}

Node * findMinimum(Node *currentNode) //ham dinh nghia 
{
    if(currentNode->Left==NULL)
        return currentNode;

    return findMinimum(currentNode->Left); //Tim thay gia tri nho nhat cua   
}

void insertNode(int x)
{
    Node *tempNode;
    Node *currentNode;
    Node *parentNode;

    tempNode = (Node *) malloc(sizeof(Node));
    tempNode->data = x;
    tempNode->Left = NULL;
    tempNode->Right = NULL;

    //For the very first call
    if(root==NULL)
    {
        root = tempNode;
    }
    else
    {
        currentNode = root;
        parentNode = NULL;

        while(1)
        {
            parentNode = currentNode;

            if(x <= parentNode->data)
            {
                currentNode = currentNode->Left;

                if(currentNode==NULL)
                {
                    parentNode->Left = tempNode;
                    return;
                }
            }
            else
            {
                currentNode = currentNode->Right;

                if(currentNode==NULL)
                {
                    parentNode->Right = tempNode;
                    return;
                }
            }

        }
    }
}


void preOrderPrint(Node *root)
{
    if(root==NULL)
        return;

    printf("%d ", root->data);

    preOrderPrint(root->Left);
    preOrderPrint(root->Right);
}
