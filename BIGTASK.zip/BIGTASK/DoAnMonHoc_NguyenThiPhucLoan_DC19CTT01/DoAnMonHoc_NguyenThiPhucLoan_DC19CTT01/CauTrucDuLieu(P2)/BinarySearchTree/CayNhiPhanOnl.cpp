#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
	int  data;
	struct node* left;
	struct node* right;
}Node;
void Free(Node* root)//giai phong du lieu
{
	if(root == NULL)
		return;
	Free(root->left);
	Free(root->right);
	Free(root);
}
Node *CreateNode(int value)
{
	Node *p=(Node*)malloc(sizeof(Node));
	p->data=value;
	p->left=NULL;
	p->right=NULL;
	return p;
}
void init(Node **root)
{
	*root=NULL;
}
void Insert(Node **root, int value)//(**root) dia chi cua bien root trong ham main
{
	Node *Root = *root;
	Node *p=CreateNode(value);
	if(Root==NULL){
		Root=p;
	}
	else{
		if(Root->data > value)
		{
			Insert(&Root->left, value);
		}
		else
		{
			Insert(&Root->right, value);
		}
	}
	*root = Root;
}
void PrintNode(Node *root)
{
	if(root != NULL)
	{
		printf("%d\t", root->data);
		PrintNode(root->left);
		PrintNode(root->right);
	}
}
void SearchKey(Node** curr, int key, Node**parent)
{
    Node *Curr = *curr;
	while (Curr != NULL && Curr->data != key)
    {
        *parent = Curr;
        if (key < Curr->data) {
            Curr = Curr->left;
        }
        else {
            Curr = Curr->right;
        }
    }
    *curr = Curr;
}

int MinLeft(Node *root)
{
	while(root->left != NULL)
	{
		root=root->left;
	}
	return root->data;	
}
Node* getMinKey(Node* curr)
{
    while (curr->left != NULL) {
        curr = curr->left;
    }
    return curr;
}
void deleteNode(Node** Root, int key)
{
    //Con tro chua dia chi cua nut cha nut can xoa
   	Node *root = *Root;
   	Node *parent = NULL; //chua dia chi nut cha cua nut bi xoa
   	Node* curr = root;
	SearchKey(&curr, key, &parent);
    if (curr == NULL) // neu tim ko thay
	{
        return;
    }
    // Case 1: nut xoa la nut la
    if (curr->left == NULL && curr->right == NULL)
    {
        if (curr != root)
        {
            if (parent->left == curr) {
                parent->left = NULL;
            }
            else {
                parent->right = NULL;
            }
        }
        // neu nut xoa la nut goc
        else {
            root = NULL;
        }
        free(curr);       
    }
    // Case 2: nut bi xoa co 2 nut con
    else if (curr->left && curr->right)
    {
        // tim nut chua gia tri nho nhat cua cay con P
        Node* successor = getMinKey(curr->right);
 
        //lay gia tri nho nhat cua cay con P
        int val = successor->data;		
        deleteNode(&curr, successor->data);
        curr->data = val;
    }
 
    // Case 3: nut bi xoa co 1 nut con
    else {
        Node* child = (curr->left)? curr->left: curr->right;
		if (curr != root)
        {
            if (curr == parent->left) {
                parent->left = child;
            }
            else {
                parent->right = child;
            }
        }
        else {
            root = child;
        }
        free(curr);
    }
    
}
int main()
{
	Node *root;
	init(&root);
	Insert(&root,9);
	Insert(&root,8);
	Insert(&root,10);
	Insert(&root,5);
	Insert(&root,12);
	
	printf("truoc khi xoa\n");
	PrintNode(root);
	
	deleteNode(&root, 9);
	printf("\nsau khi xoa\n");
	PrintNode(root);
}


