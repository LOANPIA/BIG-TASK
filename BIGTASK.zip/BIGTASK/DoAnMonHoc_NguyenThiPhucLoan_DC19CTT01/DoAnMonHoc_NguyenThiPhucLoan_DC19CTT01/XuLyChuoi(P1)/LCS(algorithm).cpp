#include<stdio.h>
#include<string.h>

int i, j, m, n, A[10][10];
char x[10], y[10], B[10][10];

void print(int i, int j){
	if(i==0 || j==0)
		return;
	if(B[i][j] == 'c'){ // co the la u 
		print(i-1,j-1);
		printf("%c",x[i-1]);
	}
	else if(B[i][j] == 'u') // co the la c 
		print(i-1,j);
	else 
		print(i,j-1);
}

void LCS(){
	m=strlen(x);
	n=strlen(y);
	for(i=0;i<m;i++)
		A[i][0]=0;
	for(i=0;i<=n;i++)
		A[0][i]=0;
	for(i=1;i<=m;i++)
		for(j=1;j<=n;j++){
			if(x[i-1]==y[j-1]){
				A[i][j]=A[i-1][j-1]+1;
				B[i][j]='c'; // co the la u 
			}
			else if(A[i-1][j]>=A[i][j-1]){
				A[i][j]=A[i-1][j];
				B[i][j]='u'; // co the la c 
			}else{ //<= or == (bang chi so cua A khong phai cua x,y
				A[i][j]=A[i][j-1];
				B[i][j]='l';
			}
		}
}

int max(int num1, int num2)
{
    return (num1 > num2 ) ? num1 : num2;
}

void Dodaixaucon(char *x, char *y){
   //int p = x.length(), q = y.length();
   //int A[2][n + 1];
   	int p=strlen(x);
	int q=strlen(y);
   int index;
   int num1 = A[1-index][j];
   int num2 = A[index][j-1];
   for (int i = 0; i <= m; i++) {
      index = i & 1;
      for (int j = 0; j <= n; j++) {
         if (i == 0 || j == 0)
            A[index][j] = 0;
         else if (x[i-1] == y[j-1])
            A[index][j] = A[1 - index][j - 1] + 1;
         else
            A[index][j] = max(A[1 - index][j], A[index][j - 1]);
            //A[index][j] = A[index-1][j];
      }
   }
   printf("\nDo dai xau lon nhat: %d",A[index][n]);
}
int main(){
	printf("Nhap xau 1: ");
	//scanf("%s",x); 
	gets(x);
	printf("Nhap xau 2: ");
	//scanf("%s",y);
	gets(y);
	printf("\nXau con chung dai nhat: ");
	LCS();
	print(m,n);
	Dodaixaucon(x,y);
	return 0;
}
