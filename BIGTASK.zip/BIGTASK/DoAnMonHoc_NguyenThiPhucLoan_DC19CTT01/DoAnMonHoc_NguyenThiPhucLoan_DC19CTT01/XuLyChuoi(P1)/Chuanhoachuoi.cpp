// chuan hoa xau-chuoi ky tu
/*
	* xoa cac ky tu khoang trang thua o cuoi xau TAIL 
	* xoa ky tu khoang trang thua o dau cau HEAD 
	* xoa ky tu khoang trang thua o giua xau MID 
	* viet hoa ky tu dau 
*/ 
#include<stdio.h>
#include<string.h> //sd cho ham strlen 
#include<stdlib.h>
#include<stdbool.h> //sd cho ham bool 
#include<ctype.h> //toupper

//ham kiem tra xuat hien khoang trang 
bool KhoangTrang(char c){
	return c == ' ' || c == '\t' || c == '\n'; 
}

//ham kiem tra xuat hien ky tu dac biet -- xoa MID
bool KyTuDB(char c){
	return c == ',' || c == '.' || c == '(' || c == ')' 
	|| c == '?' || c == ':' || c == ';' || c == '!';
}


void xoaKhoangTrangTAIL(char*);
void xoaKhoangTrangTAIL(char *Str){
	int len = strlen(Str); //lay do dai chuoi
	int i = len - 1; 
	while(KhoangTrang(Str[i])){
		Str[i] = '\0';// NULL empty 
		i--; //giam i xuong de xoa khoang trang 
	} //vong lap se ket thuc khi gap ky tu dau tien khong phai la khoang trang 
}

void xoaKhoangTrangHEAD(char*); 
void xoaKhoangTrangHEAD(char *Str){
	int dem = 0;
	int i;
	int len = strlen(Str);
	// dem co bao nhieu kytru khoang trang o dau 
	for(i=0;i<len;i++){
		if(KhoangTrang(Str[i])){
			dem++;
		}else{
			break; 
		} 
	} 
	//xoa khoang trang
	// dich chuyen kytu o sau toi truoc == sodem  
	for(i=0; i <= len-dem; i++){ //<= de copy ca ky tu NULL o cuoi  
		Str[i] = Str[i+dem]; //dich sang trai tat ca ky tu dang sau cac ky tu khoang trang o dau 1 luong = dem  
	} 
}

void xoaKhoangTrangMID(char*);
void xoaKhoangTrangMID(char *Str){
	int i,j;
	int len = strlen(Str);
	for(i=0;i<len;i++){
		// case1. 2 khoang trang lien tiep, xoa 1
		if(KhoangTrang(Str[i]) && KhoangTrang(Str[i+1])){
			// xoa khoang trang i+1 khoang trang hien thoi 
			for(j=i+1;j<len;j++){ // vi tri j = i + 1 la vi tri khoang trang thu 2
				Str[j] = Str[j+1]; //dich tat ca cac ky tu phai sang trai
			} 
			i--; 
			/*lui i trong case co qua nhieu dau cach lien nhau 
			thi lui lai 1 dau cach 
			de kiem tra con sot lai dau cach nao o ky tu ke tiep khong*/
			len--; //cap nhat bien do dai
		} 
		// case2. 1 khoang trang dung truoc ky tu dac biet
		else if(KhoangTrang(Str[i]) && KyTuDB(Str[i+1])){
			for(j=i;j<len;j++){ //xoa khoang trang truoc ky tu DB ma ky tu DB dang o vi tri i+1
				Str[j] = Str[j+1];
			} 
			i--; 
			len--;
		} else if (Str[i] == '\t'){ //TAB
			Str[i] = ' ';
		}
	}
}

void VietHoaKyTuDau(char Str[]){
	// lAP trinh C => Lap Trinh C
	// Str[0] => viet hoa
	// Str[i-1] la khoang trang => Str[i] viet hoa
	// ASCII space SPC--32
	for(int i=0; i<strlen(Str);i++){
		if(i==0 || (i>0 && Str[i-1] == 32)){ //viet hoa chu cai dau
			if(Str[i]>=97 && Str[i]<=122)
				Str[i] = Str[i] - 32; //97 -32 = 65(A)
		}else{ //viet thuong nhung chu cai ben trong
			if(Str[i]>=65 && Str[i]<=90)
				Str[i] = Str[i] + 32;
		}
	}
}

int main(){
   FILE *fp;
  char Str[100];

  fp = fopen("CHC.txt", "r");
  while(!feof(fp)) {
    if(fgets(Str, 99, fp)) 
        printf("%s", Str);
  }

  fclose(fp);

//	printf("Nhap chuoi: ");
	//fgets(Str, sizeof(Str), stdin); //doc chuoi
	//fgets(Str, 99, stdin);
	int first = strlen(Str); 
	xoaKhoangTrangTAIL(Str);
	xoaKhoangTrangHEAD(Str); 
	xoaKhoangTrangMID(Str);
	int last = strlen(Str); 
	printf("Chuoi sau khi duoc chuan hoa: %s\n", Str);
//	char* KetQua = VietHoaKyTuDau(Str);
//    puts(KetQua);
	VietHoaKyTuDau(Str);
	printf("Chuoi da viet hoa ky tu dau: %s\n", Str);
	//printf("Do dai chuoi: %d", strlen(Str));
	printf("Do dai luc dau - Do dai sau chuan hoa: %d - %d", first, last); 
	return 0; 
} 
