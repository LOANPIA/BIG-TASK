/* kiem tra trong xau ban dau co bnh lan xuat hien cua s1
tao xau moi s bo qua s1 vao trong xau ketqua
thay the vi tri s1 bang xau s2 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int demxauxuathien(char *s, char *s1){ //tim su xuat hien cua xau s1 trong xau s
	int dem = 0;
	int i;
	for(i=0; s[i] != '\0';i++){
		if(strstr(&s[i], s1) == &s[i]){ 
		//ham strstr la tim chuoi con, tra ve con tro 
		//tro den vi tri dau tien xuat hien xau s1 trong xau s, vi co the xh nhieu s1 trong s
		//-> so sanh tung xau con danh dau tai vi tri thu i trong xau s voi s1
			dem++; //tang bien dem
		}
	}	
	return dem;
}

//occurent -- bien dong -- luongxuathien tu ham demxauxuathien

void thaythe(char *s, char *s1, char *s2){
	int biendong = demxauxuathien(s, s1); //bien do dong//s1 xuat hien bao nhieu lan trong s
	int lens1 = strlen(s1);
	int lens2 = strlen(s2);
	int len  = strlen(s);
	//lay do dai de sau khi thay the la bnh --> cap phat dong on dinh hon
	char* R = (char *) malloc(len + biendong * (lens2 - lens1) + 1);
	int i = 0, j = 0;
	for(i = 0; s[i] != '\0'; ){
		if(strstr(&s[i], s1) == &s[i]){
			// s1 xh tai vi tri i trong xau s
			strcpy(&R[j], s2);
			//copy 
			i += lens1;
			j += lens2; 
		}else{ //truong hop khong tim thay xau
			R[j++] = s[i++]; 
		}
	}
	R[j] = '\0';
	puts(R);
}

int main(){
	FILE *fp;
  char s[1000];

  fp = fopen("TimKiemThayThe.txt", "r");
  while(!feof(fp)) {
    if(fgets(s, 999, fp)) 
        printf("%s", s);
  }

  fclose(fp);
//	char s[1000]; //input 
	char s1[100]; //token 
//	fgets(s, 999, stdin);
	fgets(s1, 99, stdin);
	int len = strlen(s1);
	if(len>0){
		s1[len-1] = '\0';
	}
	int size = strlen(s);
	if(size>0){
		s[size-1] = '\0';
	}
	char s2[100]; //des 
	fgets(s2, 99, stdin);
	int newLen = strlen(s2);
	if(newLen>0){
		s2[newLen-1] = '\0';
	}
	thaythe(s, s1, s2);
	//puts(input);
	return 0;
}
