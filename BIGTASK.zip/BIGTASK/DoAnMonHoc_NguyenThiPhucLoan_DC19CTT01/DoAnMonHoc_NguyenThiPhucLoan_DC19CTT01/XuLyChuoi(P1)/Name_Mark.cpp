#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	float Diem; 
	char *Ten ;
	char *Ho ;
	FILE *f = fopen("Name_Mark.txt","r");
	if(f == NULL){
		printf("\nKo mo duoc File.");
	}
	else{
		char str[255];
		fgets(str,255,f);
		Ho = strtok(str,";");
		Ten = strtok(NULL,";");
		char *d = strtok(NULL,";");
      	Diem = atof(d) ;
		printf("\nHo va ten : %s %s",Ho,Ten);
      	printf("\nDiem : %0.2f",Diem);
	}
}
