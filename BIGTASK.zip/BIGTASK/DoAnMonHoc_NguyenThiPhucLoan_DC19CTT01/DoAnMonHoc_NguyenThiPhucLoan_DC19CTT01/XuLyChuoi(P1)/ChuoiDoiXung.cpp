#include <stdio.h>
#include <string.h>

//palindromeString
int kiemtradoixung(char x[]){ //ham tra ve so nguyen 0|1
	//1 -> doi xung
	//0 -> khong doi xung
	//TI -- x[i] TT--x[len-i-1]
	size_t len = strlen(x);
	for(int i=0; i<len/2; i++){
		if(x[i] != x[len-i-1]) //vi tri dau va vi tri doi xung qua chuoi sai
			return 0;
	}
	return 1;
}

void xoaXuongDong(char x[]){
	size_t len = strlen(x);
		// TITV\n\0 => TITV\0\0
		if(x[len-1]=='\n'){
			x[len-1]='\0';
		}
}

int main(){
	FILE *fp;
  char s[50];

  fp = fopen("Palindrome.txt", "r");
  while(!feof(fp)) {
    if(fgets(s, sizeof(s), fp)) 
        printf("%s", s);
  }

  fclose(fp);
//	char s[50];
//	printf("Nhap chuoi s: ");
//	fgets(s, sizeof(s), stdin); //fgets du 1 \n
	xoaXuongDong(s);
	if(kiemtradoixung(s)){
		printf("Day la chuoi doi xung!");
	} else {
		printf("Day la chuoi khong doi xung!");
	}	
}
